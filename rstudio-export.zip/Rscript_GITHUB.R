data(mtcars)
sumary_table <- sumary(mtcars)